#ifndef __DIGICERT__
#define __DIGICERT__

extern const char* DigiCertGlobalRootCA_crt;

#endif
